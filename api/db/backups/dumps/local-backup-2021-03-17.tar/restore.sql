--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE hoop_db;
--
-- Name: hoop_db; Type: DATABASE; Schema: -; Owner: philip.johnston
--

CREATE DATABASE hoop_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE hoop_db OWNER TO "philip.johnston";

\connect hoop_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Coach; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Coach" (
    id integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    handle text NOT NULL,
    name text NOT NULL,
    "teamId" integer,
    type text,
    "isAssistant" text
);


ALTER TABLE public."Coach" OWNER TO postgres;

--
-- Name: Coach_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Coach_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Coach_id_seq" OWNER TO postgres;

--
-- Name: Coach_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Coach_id_seq" OWNED BY public."Coach".id;


--
-- Name: ColorScheme; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ColorScheme" (
    id integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "primary" text NOT NULL,
    secondary text NOT NULL,
    "teamId" integer
);


ALTER TABLE public."ColorScheme" OWNER TO postgres;

--
-- Name: ColorScheme_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ColorScheme_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ColorScheme_id_seq" OWNER TO postgres;

--
-- Name: ColorScheme_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ColorScheme_id_seq" OWNED BY public."ColorScheme".id;


--
-- Name: Player; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Player" (
    id integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    handle text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    "teamId" integer,
    height text NOT NULL,
    weight text NOT NULL,
    number text,
    "position" text
);


ALTER TABLE public."Player" OWNER TO postgres;

--
-- Name: Player_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Player_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Player_id_seq" OWNER TO postgres;

--
-- Name: Player_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Player_id_seq" OWNED BY public."Player".id;


--
-- Name: Team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Team" (
    id integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    handle text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    city text NOT NULL,
    abbreviation text NOT NULL,
    logo text NOT NULL,
    "logoSlug" text NOT NULL,
    wins integer,
    losses integer,
    "winPercentage" numeric(65,30),
    conference text NOT NULL,
    division text NOT NULL,
    established text NOT NULL,
    "primaryColor" text NOT NULL,
    "secondaryColor" text NOT NULL
);


ALTER TABLE public."Team" OWNER TO postgres;

--
-- Name: Team_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Team_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Team_id_seq" OWNER TO postgres;

--
-- Name: Team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Team_id_seq" OWNED BY public."Team".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    compound_id text NOT NULL,
    user_id integer NOT NULL,
    provider_type text NOT NULL,
    provider_id text NOT NULL,
    provider_account_id text NOT NULL,
    refresh_token text,
    access_token text,
    access_token_expires timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_id_seq OWNER TO postgres;

--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    expires timestamp(3) without time zone NOT NULL,
    session_token text NOT NULL,
    access_token text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sessions_id_seq OWNER TO postgres;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name text,
    email text,
    email_verified timestamp(3) without time zone,
    image text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: verification_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verification_requests (
    id integer NOT NULL,
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.verification_requests OWNER TO postgres;

--
-- Name: verification_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.verification_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.verification_requests_id_seq OWNER TO postgres;

--
-- Name: verification_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.verification_requests_id_seq OWNED BY public.verification_requests.id;


--
-- Name: Coach id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Coach" ALTER COLUMN id SET DEFAULT nextval('public."Coach_id_seq"'::regclass);


--
-- Name: ColorScheme id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ColorScheme" ALTER COLUMN id SET DEFAULT nextval('public."ColorScheme_id_seq"'::regclass);


--
-- Name: Player id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Player" ALTER COLUMN id SET DEFAULT nextval('public."Player_id_seq"'::regclass);


--
-- Name: Team id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Team" ALTER COLUMN id SET DEFAULT nextval('public."Team_id_seq"'::regclass);


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: verification_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_requests ALTER COLUMN id SET DEFAULT nextval('public.verification_requests_id_seq'::regclass);


--
-- Data for Name: Coach; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Coach" (id, "createdAt", "updatedAt", handle, name, "teamId", type, "isAssistant") FROM stdin;
\.
COPY public."Coach" (id, "createdAt", "updatedAt", handle, name, "teamId", type, "isAssistant") FROM '$$PATH$$/3364.dat';

--
-- Data for Name: ColorScheme; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ColorScheme" (id, "createdAt", "updatedAt", "primary", secondary, "teamId") FROM stdin;
\.
COPY public."ColorScheme" (id, "createdAt", "updatedAt", "primary", secondary, "teamId") FROM '$$PATH$$/3366.dat';

--
-- Data for Name: Player; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Player" (id, "createdAt", "updatedAt", handle, name, slug, "teamId", height, weight, number, "position") FROM stdin;
\.
COPY public."Player" (id, "createdAt", "updatedAt", handle, name, slug, "teamId", height, weight, number, "position") FROM '$$PATH$$/3368.dat';

--
-- Data for Name: Team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Team" (id, "createdAt", "updatedAt", handle, name, slug, city, abbreviation, logo, "logoSlug", wins, losses, "winPercentage", conference, division, established, "primaryColor", "secondaryColor") FROM stdin;
\.
COPY public."Team" (id, "createdAt", "updatedAt", handle, name, slug, city, abbreviation, logo, "logoSlug", wins, losses, "winPercentage", conference, division, established, "primaryColor", "secondaryColor") FROM '$$PATH$$/3370.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3372.dat';

--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, compound_id, user_id, provider_type, provider_id, provider_account_id, refresh_token, access_token, access_token_expires, created_at, updated_at) FROM stdin;
\.
COPY public.accounts (id, compound_id, user_id, provider_type, provider_id, provider_account_id, refresh_token, access_token, access_token_expires, created_at, updated_at) FROM '$$PATH$$/3373.dat';

--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, user_id, expires, session_token, access_token, created_at, updated_at) FROM stdin;
\.
COPY public.sessions (id, user_id, expires, session_token, access_token, created_at, updated_at) FROM '$$PATH$$/3375.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, email_verified, image, created_at, updated_at) FROM stdin;
\.
COPY public.users (id, name, email, email_verified, image, created_at, updated_at) FROM '$$PATH$$/3377.dat';

--
-- Data for Name: verification_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verification_requests (id, identifier, token, expires, created_at, updated_at) FROM stdin;
\.
COPY public.verification_requests (id, identifier, token, expires, created_at, updated_at) FROM '$$PATH$$/3379.dat';

--
-- Name: Coach_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Coach_id_seq"', 231, true);


--
-- Name: ColorScheme_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ColorScheme_id_seq"', 33, true);


--
-- Name: Player_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Player_id_seq"', 510, true);


--
-- Name: Team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Team_id_seq"', 31, true);


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_id_seq', 1, false);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sessions_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: verification_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.verification_requests_id_seq', 1, false);


--
-- Name: Coach Coach_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Coach"
    ADD CONSTRAINT "Coach_pkey" PRIMARY KEY (id);


--
-- Name: ColorScheme ColorScheme_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ColorScheme"
    ADD CONSTRAINT "ColorScheme_pkey" PRIMARY KEY (id);


--
-- Name: Player Player_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Player"
    ADD CONSTRAINT "Player_pkey" PRIMARY KEY (id);


--
-- Name: Team Team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Team"
    ADD CONSTRAINT "Team_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification_requests verification_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_requests
    ADD CONSTRAINT verification_requests_pkey PRIMARY KEY (id);


--
-- Name: Coach.handle_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Coach.handle_unique" ON public."Coach" USING btree (handle);


--
-- Name: Coach.name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Coach.name_unique" ON public."Coach" USING btree (name);


--
-- Name: Player.handle_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Player.handle_unique" ON public."Player" USING btree (handle);


--
-- Name: Player.name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Player.name_unique" ON public."Player" USING btree (name);


--
-- Name: Player.slug_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Player.slug_unique" ON public."Player" USING btree (slug);


--
-- Name: Team.abbreviation_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.abbreviation_unique" ON public."Team" USING btree (abbreviation);


--
-- Name: Team.handle_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.handle_unique" ON public."Team" USING btree (handle);


--
-- Name: Team.logoSlug_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.logoSlug_unique" ON public."Team" USING btree ("logoSlug");


--
-- Name: Team.logo_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.logo_unique" ON public."Team" USING btree (logo);


--
-- Name: Team.name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.name_unique" ON public."Team" USING btree (name);


--
-- Name: Team.slug_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.slug_unique" ON public."Team" USING btree (slug);


--
-- Name: accounts.compound_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "accounts.compound_id_unique" ON public.accounts USING btree (compound_id);


--
-- Name: providerAccountId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "providerAccountId" ON public.accounts USING btree (provider_account_id);


--
-- Name: providerId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "providerId" ON public.accounts USING btree (provider_id);


--
-- Name: sessions.access_token_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "sessions.access_token_unique" ON public.sessions USING btree (access_token);


--
-- Name: sessions.session_token_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "sessions.session_token_unique" ON public.sessions USING btree (session_token);


--
-- Name: userId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "userId" ON public.accounts USING btree (user_id);


--
-- Name: users.email_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users.email_unique" ON public.users USING btree (email);


--
-- Name: verification_requests.token_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "verification_requests.token_unique" ON public.verification_requests USING btree (token);


--
-- Name: Coach Coach_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Coach"
    ADD CONSTRAINT "Coach_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ColorScheme ColorScheme_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ColorScheme"
    ADD CONSTRAINT "ColorScheme_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Player Player_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Player"
    ADD CONSTRAINT "Player_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

