--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE hoop_db;
--
-- Name: hoop_db; Type: DATABASE; Schema: -; Owner: philip.johnston
--

CREATE DATABASE hoop_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE hoop_db OWNER TO "philip.johnston";

\connect hoop_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Coach; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Coach" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    handle text NOT NULL,
    name text NOT NULL,
    type text,
    "isAssistant" text,
    "teamId" text
);


ALTER TABLE public."Coach" OWNER TO postgres;

--
-- Name: ColorScheme; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ColorScheme" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "primary" text NOT NULL,
    secondary text NOT NULL,
    "teamId" text
);


ALTER TABLE public."ColorScheme" OWNER TO postgres;

--
-- Name: Player; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Player" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    handle text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    height text NOT NULL,
    weight text NOT NULL,
    number text,
    "position" text,
    "teamId" text
);


ALTER TABLE public."Player" OWNER TO postgres;

--
-- Name: Team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Team" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    handle text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    city text NOT NULL,
    abbreviation text NOT NULL,
    logo text NOT NULL,
    "logoSlug" text NOT NULL,
    wins integer,
    losses integer,
    "winPercentage" double precision,
    conference text NOT NULL,
    division text NOT NULL,
    established text NOT NULL
);


ALTER TABLE public."Team" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Data for Name: Coach; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Coach" (id, "createdAt", "updatedAt", handle, name, type, "isAssistant", "teamId") FROM stdin;
\.
COPY public."Coach" (id, "createdAt", "updatedAt", handle, name, type, "isAssistant", "teamId") FROM '$$PATH$$/3298.dat';

--
-- Data for Name: ColorScheme; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ColorScheme" (id, "createdAt", "updatedAt", "primary", secondary, "teamId") FROM stdin;
\.
COPY public."ColorScheme" (id, "createdAt", "updatedAt", "primary", secondary, "teamId") FROM '$$PATH$$/3300.dat';

--
-- Data for Name: Player; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Player" (id, "createdAt", "updatedAt", handle, name, slug, height, weight, number, "position", "teamId") FROM stdin;
\.
COPY public."Player" (id, "createdAt", "updatedAt", handle, name, slug, height, weight, number, "position", "teamId") FROM '$$PATH$$/3299.dat';

--
-- Data for Name: Team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Team" (id, "createdAt", "updatedAt", handle, name, slug, city, abbreviation, logo, "logoSlug", wins, losses, "winPercentage", conference, division, established) FROM stdin;
\.
COPY public."Team" (id, "createdAt", "updatedAt", handle, name, slug, city, abbreviation, logo, "logoSlug", wins, losses, "winPercentage", conference, division, established) FROM '$$PATH$$/3301.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3297.dat';

--
-- Name: Coach Coach_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Coach"
    ADD CONSTRAINT "Coach_pkey" PRIMARY KEY (id);


--
-- Name: ColorScheme ColorScheme_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ColorScheme"
    ADD CONSTRAINT "ColorScheme_pkey" PRIMARY KEY (id);


--
-- Name: Player Player_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Player"
    ADD CONSTRAINT "Player_pkey" PRIMARY KEY (id);


--
-- Name: Team Team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Team"
    ADD CONSTRAINT "Team_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Coach.handle_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Coach.handle_unique" ON public."Coach" USING btree (handle);


--
-- Name: Coach.name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Coach.name_unique" ON public."Coach" USING btree (name);


--
-- Name: ColorScheme_teamId_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ColorScheme_teamId_unique" ON public."ColorScheme" USING btree ("teamId");


--
-- Name: Player.handle_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Player.handle_unique" ON public."Player" USING btree (handle);


--
-- Name: Player.name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Player.name_unique" ON public."Player" USING btree (name);


--
-- Name: Player.slug_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Player.slug_unique" ON public."Player" USING btree (slug);


--
-- Name: Team.abbreviation_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.abbreviation_unique" ON public."Team" USING btree (abbreviation);


--
-- Name: Team.handle_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.handle_unique" ON public."Team" USING btree (handle);


--
-- Name: Team.logoSlug_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.logoSlug_unique" ON public."Team" USING btree ("logoSlug");


--
-- Name: Team.logo_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.logo_unique" ON public."Team" USING btree (logo);


--
-- Name: Team.name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.name_unique" ON public."Team" USING btree (name);


--
-- Name: Team.slug_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.slug_unique" ON public."Team" USING btree (slug);


--
-- Name: Coach Coach_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Coach"
    ADD CONSTRAINT "Coach_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ColorScheme ColorScheme_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ColorScheme"
    ADD CONSTRAINT "ColorScheme_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Player Player_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Player"
    ADD CONSTRAINT "Player_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

